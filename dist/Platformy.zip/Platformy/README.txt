How to Launch:
In this folder, there shold be a file labeled "Platformy"
Right click it, and open with Terminal
It may take a moment to download the assets